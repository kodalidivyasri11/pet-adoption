import { View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput, Image } from 'react-native';
import { useFonts, Inter_400Regular, Inter_600SemiBold } from '@expo-google-fonts/inter';
import { ChevronRight, Heart, Bell, Settings, Camera, Mail, User as UserIcon, Phone } from 'lucide-react-native';
import { useEffect, useState } from 'react';
import { SplashScreen } from 'expo-router';

SplashScreen.preventAutoHideAsync();

const MENU_ITEMS = [
  { icon: Heart, label: 'My Applications', color: '#FF6B6B' },
  { icon: Bell, label: 'Notifications', color: '#4299E1' },
  { icon: Settings, label: 'Settings', color: '#48BB78' },
];

interface ProfileData {
  name: string;
  email: string;
  phone: string;
  bio: string;
}

export default function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  const [profileData, setProfileData] = useState<ProfileData>({
    name: 'John Doe',
    email: 'john.doe@example.com',
    phone: '+1 (555) 123-4567',
    bio: 'Animal lover and aspiring pet parent. Looking forward to providing a loving home to a furry friend.',
  });
  const [tempData, setTempData] = useState<ProfileData>(profileData);

  const [fontsLoaded, fontError] = useFonts({
    'Inter-Regular': Inter_400Regular,
    'Inter-SemiBold': Inter_600SemiBold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) {
    return null;
  }

  const handleSave = () => {
    setProfileData(tempData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setTempData(profileData);
    setIsEditing(false);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Profile</Text>
        <TouchableOpacity
          style={styles.editButton}
          onPress={() => isEditing ? handleSave() : setIsEditing(true)}
        >
          <Text style={styles.editButtonText}>
            {isEditing ? 'Save' : 'Edit'}
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content}>
        <View style={styles.profileSection}>
          <View style={styles.avatarContainer}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>
                {profileData.name.split(' ').map(n => n[0]).join('')}
              </Text>
            </View>
            {isEditing && (
              <TouchableOpacity style={styles.cameraButton}>
                <Camera size={20} color="#FFFFFF" />
              </TouchableOpacity>
            )}
          </View>

          <View style={styles.profileFields}>
            <View style={styles.fieldContainer}>
              <UserIcon size={20} color="#718096" style={styles.fieldIcon} />
              {isEditing ? (
                <TextInput
                  style={styles.input}
                  value={tempData.name}
                  onChangeText={(text) => setTempData({ ...tempData, name: text })}
                  placeholder="Your name"
                />
              ) : (
                <Text style={styles.fieldValue}>{profileData.name}</Text>
              )}
            </View>

            <View style={styles.fieldContainer}>
              <Mail size={20} color="#718096" style={styles.fieldIcon} />
              {isEditing ? (
                <TextInput
                  style={styles.input}
                  value={tempData.email}
                  onChangeText={(text) => setTempData({ ...tempData, email: text })}
                  placeholder="Your email"
                  keyboardType="email-address"
                />
              ) : (
                <Text style={styles.fieldValue}>{profileData.email}</Text>
              )}
            </View>

            <View style={styles.fieldContainer}>
              <Phone size={20} color="#718096" style={styles.fieldIcon} />
              {isEditing ? (
                <TextInput
                  style={styles.input}
                  value={tempData.phone}
                  onChangeText={(text) => setTempData({ ...tempData, phone: text })}
                  placeholder="Your phone number"
                  keyboardType="phone-pad"
                />
              ) : (
                <Text style={styles.fieldValue}>{profileData.phone}</Text>
              )}
            </View>

            <View style={styles.bioContainer}>
              <Text style={styles.bioLabel}>Bio</Text>
              {isEditing ? (
                <TextInput
                  style={styles.bioInput}
                  value={tempData.bio}
                  onChangeText={(text) => setTempData({ ...tempData, bio: text })}
                  placeholder="Tell us about yourself"
                  multiline
                  numberOfLines={4}
                />
              ) : (
                <Text style={styles.bioText}>{profileData.bio}</Text>
              )}
            </View>
          </View>

          {isEditing && (
            <TouchableOpacity
              style={styles.cancelButton}
              onPress={handleCancel}
            >
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
          )}
        </View>

        <View style={styles.menuSection}>
          {MENU_ITEMS.map((item, index) => (
            <TouchableOpacity key={index} style={styles.menuItem}>
              <View style={styles.menuItemLeft}>
                <item.icon size={24} color={item.color} />
                <Text style={styles.menuItemText}>{item.label}</Text>
              </View>
              <ChevronRight size={20} color="#A0AEC0" />
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7FAFC',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: '#FFFFFF',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  title: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 24,
    color: '#2D3748',
  },
  editButton: {
    backgroundColor: '#4299E1',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  editButtonText: {
    color: '#FFFFFF',
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
  },
  content: {
    flex: 1,
  },
  profileSection: {
    backgroundColor: '#FFFFFF',
    padding: 20,
  },
  avatarContainer: {
    alignItems: 'center',
    marginBottom: 24,
    position: 'relative',
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#4299E1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 32,
    color: '#FFFFFF',
  },
  cameraButton: {
    position: 'absolute',
    bottom: 0,
    right: '35%',
    backgroundColor: '#48BB78',
    padding: 8,
    borderRadius: 20,
    borderWidth: 3,
    borderColor: '#FFFFFF',
  },
  profileFields: {
    marginTop: 20,
  },
  fieldContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    backgroundColor: '#F7FAFC',
    padding: 12,
    borderRadius: 12,
  },
  fieldIcon: {
    marginRight: 12,
  },
  fieldValue: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#2D3748',
    flex: 1,
  },
  input: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#2D3748',
    flex: 1,
    padding: 0,
  },
  bioContainer: {
    marginTop: 8,
  },
  bioLabel: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#4A5568',
    marginBottom: 8,
  },
  bioText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#718096',
    lineHeight: 20,
  },
  bioInput: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#2D3748',
    backgroundColor: '#F7FAFC',
    padding: 12,
    borderRadius: 12,
    height: 100,
    textAlignVertical: 'top',
  },
  cancelButton: {
    marginTop: 16,
    padding: 12,
    borderRadius: 12,
    backgroundColor: '#EDF2F7',
    alignItems: 'center',
  },
  cancelButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: '#4A5568',
  },
  menuSection: {
    backgroundColor: '#FFFFFF',
    marginTop: 20,
    paddingVertical: 8,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  menuItemText: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#2D3748',
    marginLeft: 12,
  },
});