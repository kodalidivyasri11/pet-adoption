import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { useFonts, Inter_400Regular, Inter_600SemiBold } from '@expo-google-fonts/inter';
import { Heart } from 'lucide-react-native';
import { useEffect, useState } from 'react';
import { SplashScreen } from 'expo-router';

SplashScreen.preventAutoHideAsync();

const PETS = [
  {
    id: 1,
    name: 'Luna',
    type: 'Dog',
    breed: 'Golden Retriever',
    age: '2 years',
    distance: '2.5 km',
    image: 'https://images.unsplash.com/photo-1552053831-71594a27632d?q=80&w=562',
  },
  {
    id: 2,
    name: 'Oliver',
    type: 'Cat',
    breed: 'British Shorthair',
    age: '1 year',
    distance: '3.8 km',
    image: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?q=80&w=562',
  },
  {
    id: 3,
    name: 'Max',
    type: 'Dog',
    breed: 'German Shepherd',
    age: '3 years',
    distance: '1.2 km',
    image: 'https://images.unsplash.com/photo-1589941013453-ec89f33b5e95?q=80&w=562',
  },
  {
    id: 4,
    name: 'Bella',
    type: 'Dog',
    breed: 'Siberian Husky',
    age: '1.5 years',
    distance: '4.2 km',
    image: 'https://images.unsplash.com/photo-1605568427561-40dd23c2acea?q=80&w=562',
  },
  {
    id: 5,
    name: 'Rocky',
    type: 'Dog',
    breed: 'Rottweiler',
    age: '4 years',
    distance: '3.1 km',
    image: 'https://images.unsplash.com/photo-1567752881298-894bb81f9379?q=80&w=562',
  },
  {
    id: 6,
    name: 'Daisy',
    type: 'Dog',
    breed: 'Labrador Retriever',
    age: '2 years',
    distance: '1.8 km',
    image: 'https://images.unsplash.com/photo-1591160690555-5debfba289f0?q=80&w=562',
  },
  {
    id: 7,
    name: 'Charlie',
    type: 'Dog',
    breed: 'French Bulldog',
    age: '1 year',
    distance: '2.9 km',
    image: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?q=80&w=562',
  },
];

export default function Favorites() {
  const [favorites, setFavorites] = useState<number[]>([1, 4, 6]); // Some initial favorites for demo
  const [fontsLoaded, fontError] = useFonts({
    'Inter-Regular': Inter_400Regular,
    'Inter-SemiBold': Inter_600SemiBold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) {
    return null;
  }

  const favoritePets = PETS.filter(pet => favorites.includes(pet.id));

  const toggleFavorite = (id: number) => {
    setFavorites(prev => prev.filter(petId => petId !== id));
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Favorites</Text>
      </View>
      <ScrollView style={styles.content}>
        {favoritePets.length === 0 ? (
          <Text style={styles.emptyText}>No favorite pets yet</Text>
        ) : (
          favoritePets.map((pet) => (
            <TouchableOpacity key={pet.id} style={styles.petCard}>
              <Image source={{ uri: pet.image }} style={styles.petImage} />
              <TouchableOpacity 
                style={styles.favoriteButton}
                onPress={() => toggleFavorite(pet.id)}
              >
                <Heart size={20} color="#FF6B6B" fill="#FF6B6B" />
              </TouchableOpacity>
              <View style={styles.petInfo}>
                <Text style={styles.petName}>{pet.name}</Text>
                <Text style={styles.petBreed}>{pet.breed}</Text>
                <View style={styles.petDetails}>
                  <Text style={styles.petAge}>{pet.age}</Text>
                  <Text style={styles.petDistance}>{pet.distance}</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7FAFC',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: '#FFFFFF',
  },
  title: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 24,
    color: '#2D3748',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  emptyText: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#718096',
    textAlign: 'center',
    marginTop: 40,
  },
  petCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginBottom: 16,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  petImage: {
    width: '100%',
    height: 200,
  },
  favoriteButton: {
    position: 'absolute',
    top: 12,
    right: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 8,
  },
  petInfo: {
    padding: 16,
  },
  petName: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: '#2D3748',
  },
  petBreed: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#718096',
    marginTop: 4,
  },
  petDetails: {
    flexDirection: 'row',
    marginTop: 8,
  },
  petAge: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#718096',
    marginRight: 16,
  },
  petDistance: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#718096',
  },
});