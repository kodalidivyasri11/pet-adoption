import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { useFonts, Inter_400Regular, Inter_600SemiBold } from '@expo-google-fonts/inter';
import { CircleCheck as CheckCircle2, Clock, Circle as XCircle } from 'lucide-react-native';
import { useEffect } from 'react';
import { SplashScreen } from 'expo-router';

SplashScreen.preventAutoHideAsync();

const APPLICATIONS = [
  {
    id: '1',
    petName: 'Luna',
    breed: 'Golden Retriever',
    status: 'approved',
    date: 'March 15, 2024',
    image: 'https://images.unsplash.com/photo-1552053831-71594a27632d?q=80&w=562',
    shelterName: 'Happy Tails Shelter',
  },
  {
    id: '2',
    petName: 'Max',
    breed: 'German Shepherd',
    status: 'pending',
    date: 'March 14, 2024',
    image: 'https://images.unsplash.com/photo-1589941013453-ec89f33b5e95?q=80&w=562',
    shelterName: 'Paws & Love Rescue',
  },
  {
    id: '3',
    petName: 'Charlie',
    breed: 'French Bulldog',
    status: 'pending',
    date: 'March 13, 2024',
    image: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?q=80&w=562',
    shelterName: 'Second Chance Pets',
  },
  {
    id: '4',
    petName: 'Bella',
    breed: 'Siberian Husky',
    status: 'rejected',
    date: 'March 10, 2024',
    image: 'https://images.unsplash.com/photo-1605568427561-40dd23c2acea?q=80&w=562',
    shelterName: 'Forever Homes Rescue',
  },
];

export default function Applications() {
  const [fontsLoaded, fontError] = useFonts({
    'Inter-Regular': Inter_400Regular,
    'Inter-SemiBold': Inter_600SemiBold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) {
    return null;
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return '#48BB78';
      case 'pending':
        return '#ECC94B';
      case 'rejected':
        return '#F56565';
      default:
        return '#718096';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle2 size={20} color="#48BB78" />;
      case 'pending':
        return <Clock size={20} color="#ECC94B" />;
      case 'rejected':
        return <XCircle size={20} color="#F56565" />;
      default:
        return null;
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My Applications</Text>
      </View>

      <ScrollView style={styles.content}>
        {APPLICATIONS.map((application) => (
          <TouchableOpacity key={application.id} style={styles.applicationCard}>
            <Image source={{ uri: application.image }} style={styles.petImage} />
            <View style={styles.applicationInfo}>
              <View style={styles.applicationHeader}>
                <Text style={styles.petName}>{application.petName}</Text>
                <View style={[
                  styles.statusBadge,
                  { backgroundColor: `${getStatusColor(application.status)}15` }
                ]}>
                  <View style={styles.statusIcon}>
                    {getStatusIcon(application.status)}
                  </View>
                  <Text style={[
                    styles.statusText,
                    { color: getStatusColor(application.status) }
                  ]}>
                    {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                  </Text>
                </View>
              </View>
              <Text style={styles.breed}>{application.breed}</Text>
              <Text style={styles.shelterName}>{application.shelterName}</Text>
              <Text style={styles.date}>Applied on {application.date}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7FAFC',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: '#FFFFFF',
  },
  title: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 24,
    color: '#2D3748',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  applicationCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginBottom: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  petImage: {
    width: '100%',
    height: 200,
  },
  applicationInfo: {
    padding: 16,
  },
  applicationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  petName: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: '#2D3748',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  statusIcon: {
    marginRight: 6,
  },
  statusText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
  },
  breed: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#718096',
    marginBottom: 4,
  },
  shelterName: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#4A5568',
    marginBottom: 4,
  },
  date: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#718096',
  },
});