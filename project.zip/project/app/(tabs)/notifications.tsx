import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useFonts, Inter_400Regular, Inter_600SemiBold } from '@expo-google-fonts/inter';
import { Bell, CircleCheck as CheckCircle2, Clock, Circle as XCircle } from 'lucide-react-native';
import { useEffect, useState } from 'react';
import { SplashScreen } from 'expo-router';

SplashScreen.preventAutoHideAsync();

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'pending' | 'rejected';
  timestamp: string;
  read: boolean;
}

const NOTIFICATIONS: Notification[] = [
  {
    id: '1',
    title: 'Application Approved',
    message: 'Your application to adopt Luna has been approved! Please check your email for next steps.',
    type: 'success',
    timestamp: '2 hours ago',
    read: false,
  },
  {
    id: '2',
    title: 'Application Under Review',
    message: 'Your application for Max is being reviewed by the shelter.',
    type: 'pending',
    timestamp: '1 day ago',
    read: false,
  },
  {
    id: '3',
    title: 'Application Update Required',
    message: 'Please update your application for Charlie with additional documentation.',
    type: 'info',
    timestamp: '2 days ago',
    read: true,
  },
  {
    id: '4',
    title: 'Application Status',
    message: 'Unfortunately, your application for Bella was not approved at this time.',
    type: 'rejected',
    timestamp: '3 days ago',
    read: true,
  },
];

export default function Notifications() {
  const [notifications, setNotifications] = useState<Notification[]>(NOTIFICATIONS);
  const [fontsLoaded, fontError] = useFonts({
    'Inter-Regular': Inter_400Regular,
    'Inter-SemiBold': Inter_600SemiBold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) {
    return null;
  }

  const markAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
  };

  const getNotificationIcon = (type: Notification['type']) => {
    switch (type) {
      case 'success':
        return <CheckCircle2 size={24} color="#48BB78" />;
      case 'pending':
        return <Clock size={24} color="#ECC94B" />;
      case 'rejected':
        return <XCircle size={24} color="#F56565" />;
      default:
        return <Bell size={24} color="#4299E1" />;
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Notifications</Text>
        {notifications.some(n => !n.read) && (
          <TouchableOpacity
            style={styles.markAllButton}
            onPress={() => setNotifications(prev => prev.map(n => ({ ...n, read: true })))}
          >
            <Text style={styles.markAllButtonText}>Mark all as read</Text>
          </TouchableOpacity>
        )}
      </View>

      <ScrollView style={styles.content}>
        {notifications.map((notification) => (
          <TouchableOpacity
            key={notification.id}
            style={[
              styles.notificationCard,
              notification.read && styles.notificationCardRead
            ]}
            onPress={() => markAsRead(notification.id)}
          >
            <View style={styles.notificationIcon}>
              {getNotificationIcon(notification.type)}
            </View>
            <View style={styles.notificationContent}>
              <Text style={styles.notificationTitle}>{notification.title}</Text>
              <Text style={styles.notificationMessage}>{notification.message}</Text>
              <Text style={styles.notificationTime}>{notification.timestamp}</Text>
            </View>
            {!notification.read && <View style={styles.unreadDot} />}
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7FAFC',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: '#FFFFFF',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  title: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 24,
    color: '#2D3748',
  },
  markAllButton: {
    backgroundColor: '#EDF2F7',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  markAllButtonText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#4A5568',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  notificationCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'flex-start',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  notificationCardRead: {
    backgroundColor: '#F7FAFC',
  },
  notificationIcon: {
    marginRight: 12,
    padding: 8,
    backgroundColor: '#EDF2F7',
    borderRadius: 12,
  },
  notificationContent: {
    flex: 1,
  },
  notificationTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#2D3748',
    marginBottom: 4,
  },
  notificationMessage: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#4A5568',
    marginBottom: 8,
  },
  notificationTime: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#718096',
  },
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#4299E1',
    marginLeft: 8,
    marginTop: 8,
  },
});